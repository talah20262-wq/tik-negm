
const express = require('express');
const mongoose = require('mongoose');
const cloudinary = require('cloudinary').v2;
const multer = require('multer');
const { CloudinaryStorage } = require('multer-storage-cloudinary');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// DB
mongoose.connect(process.env.MONGO_URL);

// Models
const Setting = mongoose.model('Setting', { key: String, value: String });
const Video = mongoose.model('Video', { userId: String, videoUrl: String, caption: String, isVerified: Boolean });
const User = mongoose.model('User', { username: String, role: String, isVerified: { type: Boolean, default: false } });

// Cloudinary config
async function configureCloudinary() {
    cloudinary.config({
        cloud_name: process.env.CLOUD_NAME,
        api_key: process.env.CLOUD_KEY,
        api_secret: process.env.CLOUD_SECRET
    });
}
configureCloudinary();

// Storage
const storage = new CloudinaryStorage({
    cloudinary: cloudinary,
    params: {
        folder: 'najmatech',
        resource_type: 'video'
    }
});
const upload = multer({ storage });

// Admin update settings
app.post('/api/admin/update-settings', async (req, res) => {
    if (req.headers.authorization === process.env.ADMIN_PASS) {
        await Setting.findOneAndUpdate(
            { key: 'cloudinary_url' },
            { value: req.body.cloudinary_url },
            { upsert: true }
        );
        res.json({ ok: true });
    } else res.status(403).send("Unauthorized");
});

// verify user
app.post('/api/admin/verify', async (req, res) => {
    if (req.headers.authorization === process.env.ADMIN_PASS) {
        await User.findByIdAndUpdate(req.body.userId, { isVerified: true });
        res.json({ ok: true });
    } else res.status(403).send("Unauthorized");
});

// upload video
app.post('/api/upload', upload.single('video'), async (req, res) => {
    const v = new Video({
        userId: req.body.userId,
        videoUrl: req.file.path,
        caption: req.body.caption
    });
    await v.save();
    res.json({ ok: true, url: req.file.path });
});

// feed
app.get('/api/feed', async (req, res) => {
    const videos = await Video.find().sort({ _id: -1 });
    res.json(videos);
});

app.listen(3000, () => console.log("Server running"));
